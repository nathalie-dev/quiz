<?php

echo '<h1>Tableau de bord Quiz</h1>';
echo '<p>Bienvenue dans le tableau de bord Quiz ! (version include)</p>';


test(); ?>