<?php
//require_once 'models/themes.php';


// Fonction pour ajouter ou éditer un thème
function nat_quiz_save_theme()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'nat_quiz_themes';

    $id_themes = isset($_POST['id_themes']) ? $_POST['id_themes'] : '';
    $nom = isset($_POST['nom']) ? $_POST['nom'] : '';
    $descriptif = isset($_POST['descriptif']) ? $_POST['descriptif'] : '';
	$date_creation = isset($_POST['date_creation']) ? $_POST['date_creation'] : '';
    $image = isset($_POST['image']) ? $_POST['image'] : '';

    if (empty($id_themes) || empty($nom) || empty($descriptif) || empty($date_creation) || empty($image)) {
       return wp_send_json_error('Veuillez remplir tous les champs.');
    }

    $data = array(
        'id_themes' => $id_themes,
        'nom' => $nom,
        'descriptif' => $descriptif,
		'date_creation' => $date_creation,
		'image' => $image
    );

 // Ajouter ou mettre à jour un thème
 if (empty($id_themes)) {
	$wpdb->insert($table_name, $data);
} else {
	$wpdb->update($table_name, $data, array('id_themes' => $id_themes));
}

return wp_send_json_success('Thème enregistré avec succès.'); //Renvoie une réponse JSON à une requête Ajax, indiquant le succès.


}

// Ajouter une action pour enregistrer un thème en AJAX
add_action('wp_ajax_nat_quiz_save_theme', 'nat_quiz_save_theme');

// Fonction pour supprimer un thème
function nat_quiz_delete_themes()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'nat_quiz_themes';

    $id_themes = isset($_POST['id_themes']) ? $_POST['id_themes'] : '';

    if (empty($id_themes)) {
       return wp_send_json_error('ID manquant.');
    }

    $wpdb->delete($table_name, array('id_themes' => $id_themes));

    return wp_send_json_success('Thème supprimé avec succès.');
}

// Ajouter une action pour supprimer un thème en AJAX
add_action('wp_ajax_nat_quiz_delete_themes', 'nat_quiz_delete_themes');

// Fonction pour récupérer un thème en AJAX
function nat_quiz_get_themes()
{
    global $wpdb,$_POST;

    $table_name = $wpdb->prefix . 'nat_quiz_themes';

    $id_themes = isset($_POST['id_themes']) ? $_POST['id_themes'] : '';

    if (empty($id_themes)) {
       return wp_send_json_error('ID de thème manquant.');
    }

    $themes = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE id_themes = %d",
        $id_themes
    ));

    return wp_send_json_success('Theme recuperer avec succes');
}

// Ajouter une action pour récupérer les themes en AJAX
add_action('wp_ajax_nat_quiz_get_themes', 'nat_quiz_get_themes');

?>


<!-- formulaire pour créer un theme -->
<form id="nat-quiz-themes-form" class="wp-admin" method="post">

<table>

		<tr>
			<td><label for="id_themes">Thème n° : </label></td>
			<td><input id="id_themes" type="text" name="id_themes" required="true" /></td>
		</tr>

		<tr>
			<td><label for="nom">Nom du thème : </label></td>
			<td><input id="nom" type="text" name="nom" required="true" /></td>
		</tr>

		<tr>
			<td><label for="descriptif">Descriptif : </label></td>
			<td><textarea name="descriptif" required="true" /></textarea></td>
		</tr>

		<tr>
			<td><label for="date de creation">Date de création : </label></td>
			<td><input id="date" type="date" name="date de creation" required="true" /></td>
		</tr>

<!--	<tr>
			<td><label for="image">Image : </label></td>
			<td><input type="image" id="image" alt="muffin pour les fêtes de pâques" src="wp-content/plugins/nat-quiz/assets/muffin.webp" required="false" /></td> 
		</tr>
-->
</table>

    <p class="submit">
        <button type="submit" class="button button-primary">Enregistrer</button>
    </p>

</form>
<hr>
<div id="themes-list">
    <!-- La liste des thèmes sera affichée ici -->
</div>


<script>
jQuery(document).ready(function($) {
// Fonction pour récupérer la liste des thèmes
function getThemesList(id_themes) {
    $.ajax({
        url: ajaxurl,
        type: 'POST',
        dataType: 'json',
        data: { action: 'nat_quiz_get_themes', id_themes: id_themes },
        success: function(response) {
            var themes = response.data;

            // Construire la liste des thèmes en HTML
            var html = '<table class="wp-list-table widefat fixed striped posts">';
            html += '<thead><tr><th>Themes</th><th>Action</th></tr></thead><tbody>';
            for (var i = 0; i < themes.length; i++) {
                var theme = themes[i];
                html += '<tr class="theme">';
                html += '<td><h3>' + theme.nom + '</h3></td>';
                html += '<td><ul>';
                
                html += '</ul></td>';
                html += '<td><button class="delete-theme button" data-id="' + theme.id + '">Supprimer</button></td>';
                html += '</tr>';
            }
            html += '</tbody></table>';

            // Afficher la liste des themes
            $('#themes-list').html(html);
        },
        error: function(response) {
            alert('Une erreur s\'est produite. Veuillez réessayer plus tard.');
        }
    });
}
// Au chargement de la page, récupérer la liste des thèmes avec l'ID 1
    getThemesList(1);


// Supprimer un theme
$(document).on('click', '.delete-themes', function() {
    var id = $(this).data('id');
    if (confirm('Êtes-vous sûr de vouloir supprimer ce thème ?')) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: { action: 'nat_quiz_delete_themes', id: id },
            success: function(response) {
                alert(response.data);
                getThemeList(1); // Recharger la liste des themes après la suppression
            },
            error: function(response) {
                alert('Une erreur s\'est produite. Veuillez réessayer plus tard.');
            }
        });
    }
});
})
</script>





















