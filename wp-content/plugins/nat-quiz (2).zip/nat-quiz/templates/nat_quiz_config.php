<?php

echo '<h1>Questions Quiz</h1>';
echo '<p>Ici vous pouvez gérer les questions de votre quiz.</p>';

var_dump($wpdb);

