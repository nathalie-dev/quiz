<?php

echo '<h1>Statistiques Quiz</h1>';
echo '<p>Ici vous pouvez consulter les statistiques de votre quiz.</p>';