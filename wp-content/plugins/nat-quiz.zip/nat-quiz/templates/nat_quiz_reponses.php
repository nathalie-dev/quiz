<?php

echo '<h1>Réponses Quiz</h1>';
echo '<p>Ici vous pouvez gérer les réponses de votre quiz.</p>';

