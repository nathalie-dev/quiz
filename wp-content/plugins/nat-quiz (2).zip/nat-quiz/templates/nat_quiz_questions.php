<?php

echo '<h1>Questions Quiz</h1>';
echo '<p>Ici vous pouvez gérer les questions de votre quiz.</p>';

// Fonction pour ajouter ou éditer une question
function nat_quiz_save_question()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'nat_quiz_questions';

    $id = isset($_POST['id']) ? $_POST['id'] : '';
    $theme_id = isset($_POST['theme_id']) ? $_POST['theme_id'] : '';
    $question = isset($_POST['question']) ? $_POST['question'] : '';
    $answers = isset($_POST['answers']) ? $_POST['answers'] : '';

    if (empty($theme_id) || empty($question) || empty($answers)) {
        wp_send_json_error('Veuillez remplir tous les champs.');
    }

    $data = array(
        'theme_id' => $theme_id,
        'question' => $question,
        'answers' => $answers
    );

    // Ajouter ou mettre à jour la question
    if (empty($id)) {
        $wpdb->insert($table_name, $data);
    } else {
        $wpdb->update($table_name, $data, array('id' => $id));
    }

    wp_send_json_success('Question enregistrée avec succès.');
}

// Ajouter une action pour enregistrer une question en AJAX
add_action('wp_ajax_nat_quiz_save_question', 'nat_quiz_save_question');

// Fonction pour supprimer une question
function nat_quiz_delete_question()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'nat_quiz_questions';

    $id = isset($_POST['id']) ? $_POST['id'] : '';

    if (empty($id)) {
        wp_send_json_error('ID manquant.');
    }

    $wpdb->delete($table_name, array('id' => $id));

    wp_send_json_success('Question supprimée avec succès.');
}

// Ajouter une action pour supprimer une question en AJAX
add_action('wp_ajax_nat_quiz_delete_question', 'nat_quiz_delete_question');

// Fonction pour récupérer les questions d'un thème en AJAX
function nat_quiz_get_questions()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'nat_quiz_questions';

    $theme_id = isset($_POST['theme_id']) ? $_POST['theme_id'] : '';

    if (empty($theme_id)) {
        wp_send_json_error('ID de thème manquant.');
    }

    $questions = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE theme_id = %d",
        $theme_id
    ));

    wp_send_json_success($questions);
}

// Ajouter une action pour récupérer les questions en AJAX
add_action('wp_ajax_nat_quiz_get_questions', 'nat_quiz_get_questions');

?>

<form id="nat-quiz-question-form" class="wp-admin" method="post">
    <input type="hidden" name="id" value="">
    <div class="form-field">
        <label for="theme_id">ID du thème :</label>
        <input type="text" name="theme_id" required>
    </div>
    <div class="form-field">
        <label for="question">Question :</label>
        <textarea name="question" required></textarea>
    </div>
    <div class="form-field">
    <label for="answers">Réponses (séparées par des virgules) :</label>
        <input type="text" name="answers" required>
    </div>
    <p class="submit">
        <button type="submit" class="button button-primary">Enregistrer</button>
    </p>
</form>
<hr>
<div id="questions-list">
    <!-- La liste des questions sera affichée ici -->
</div>

<script>
jQuery(document).ready(function($) {
    // Fonction pour récupérer la liste des questions
    function getQuestionsList(theme_id) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: { action: 'nat_quiz_get_questions', theme_id: theme_id },
            success: function(response) {
                var questions = response.data;

                // Construire la liste des questions en HTML
                var html = '<table class="wp-list-table widefat fixed striped posts">';
                html += '<thead><tr><th>Question</th><th>Réponses</th><th>Action</th></tr></thead><tbody>';
                for (var i = 0; i < questions.length; i++) {
                    var question = questions[i];
                    html += '<tr class="question">';
                    html += '<td><h3>' + question.question + '</h3></td>';
                    html += '<td><ul>';
                    var answers = question.answers.split(',');
                    for (var j = 0; j < answers.length; j++) {
                        html += '<li>' + answers[j] + '</li>';
                    }
                    html += '</ul></td>';
                    html += '<td><button class="delete-question button" data-id="' + question.id + '">Supprimer</button></td>';
                    html += '</tr>';
                }
                html += '</tbody></table>';

                // Afficher la liste des questions
                $('#questions-list').html(html);
            },
            error: function(response) {
                alert('Une erreur s\'est produite. Veuillez réessayer plus tard.');
            }
        });
    }

    // Au chargement de la page, récupérer la liste des questions pour le thème avec l'ID 1
    getQuestionsList(1);
   

    // Supprimer une question
    $(document).on('click', '.delete-question', function() {
        var id = $(this).data('id');
        if (confirm('Êtes-vous sûr de vouloir supprimer cette question ?')) {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                dataType: 'json',
                data: { action: 'nat_quiz_delete_question', id: id },
                success: function(response) {
                    alert(response.data);
                    getQuestionsList(1); // Recharger la liste des questions après la suppression
                },
                error: function(response) {
                    alert('Une erreur s\'est produite. Veuillez réessayer plus tard.');
                }
            });
        }
    });
})
</script>
