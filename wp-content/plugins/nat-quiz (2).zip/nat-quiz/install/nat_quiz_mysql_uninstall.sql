DROP TABLE `wp_nat_quiz_admin`; 
DROP TABLE `wp_nat_quiz_questions`; 
DROP TABLE `wp_nat_quiz_reponses`; 
DROP TABLE `wp_nat_quiz_themes`; 
DROP TABLE `wp_nat_quiz_utilisateurs`; 