<?php
//function test()
//{
//   echo 'ok';
//}


