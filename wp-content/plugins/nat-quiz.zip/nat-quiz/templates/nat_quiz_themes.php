<?php

echo '<h1>Thèmes Quiz</h1>';
echo '<p>Ici vous pouvez gérer les thèmes de votre quiz.</p>';

test();


