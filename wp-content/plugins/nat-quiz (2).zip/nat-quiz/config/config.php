<?php
error_reporting(E_ALL);
ini_set('display_errors', TRUE);
ini_set('display_startup_errors', TRUE);
// Paramètres de connexion à la base de données
define('DB_HOST','localhost'); // Adresse de la base, généralement localhost
define('DB_NAME','quiz');    // Nom de la base de données
define('DB_USER','root');    // Nom de l'utilisateur MySQL
define('DB_PASS','');    // Mot de passe de l'utilisateur


?>